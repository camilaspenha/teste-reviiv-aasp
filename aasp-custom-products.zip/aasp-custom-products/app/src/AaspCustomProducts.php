<?php

use WPEmerge\Application\ApplicationTrait;

/**
 * @mixin \WPEmergeAppCore\Application\ApplicationMixin
 */
class AaspCustomProducts {
	use ApplicationTrait;
}
