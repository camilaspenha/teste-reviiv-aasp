<?php

namespace AaspCustomProducts\Wordpress\Admin\Pages;
use AaspCustomProducts\WordPress\Services\ProdutoService;

class RelatorioProdutosPage
{
    public function render()
    {

		$service = new ProdutoService();
        $tabela   = $service->getProdutos();

        ?>
			<div class="wrap">
				<h1>Relatório de Produtos Jurídicos</h1>
				<p>Bem-vindo ao relatório de produtos jurídicos. Aqui você pode visualizar e gerenciar os produtos cadastrados.</p>
				<?php echo $tabela; ?>
			</div>
        <?php
    }
}
