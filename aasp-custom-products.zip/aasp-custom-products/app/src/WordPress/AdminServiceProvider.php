<?php

namespace AaspCustomProducts\WordPress;

use WPEmerge\ServiceProviders\ServiceProviderInterface;
use AaspCustomProducts\Wordpress\Admin\Pages\RelatorioProdutosPage;
use AaspCustomProducts\WordPress\AssetsServiceProvider;

/**
 * Register admin-related entities, like admin menu pages.
 */
class AdminServiceProvider implements ServiceProviderInterface {
	/**
	 * {@inheritDoc}
	 */
	public function register( $container ) {
		// Nothing to register.
	}

	/**
	 * {@inheritDoc}
	 */
	public function bootstrap( $container ) {
		add_action( 'admin_menu', [$this, 'registerAdminPages'] );
		add_action( 'admin_css', [$this, 'registerAdminCSS'] );
	}

	/**
	 * Register admin pages.
	 *
	 * @return void
	 */
	public function registerAdminPages() {
		// phpcs:ignore
		// add_theme_page( string $page_title, string $menu_title, string $capability, string $menu_slug, callable $function = '', int $position = null );

		add_menu_page(
			'Relatório de Produtos Jurídicos',
			'Relatório de Produtos Jurídicos',
			'manage_options',
			'relatorio-produtos',
			function(){
				$page = new RelatorioProdutosPage();
				$page->render();
			},
			'dashicons-chart-bar',
			6 // Position in the menu
		);
	}

	public function registerAdminCSS(){
		$style = new AssetsServiceProvider();
		$style->bootstrap();
	}

}
