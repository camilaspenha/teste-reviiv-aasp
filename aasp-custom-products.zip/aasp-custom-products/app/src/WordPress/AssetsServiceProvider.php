<?php

namespace AaspCustomProducts\WordPress;

use WPEmerge\ServiceProviders\ServiceProviderInterface;

/**
 * Register and enqueues assets.
 */
class AssetsServiceProvider implements ServiceProviderInterface {
	/**
	 * Filesystem.
	 *
	 * @var \WP_Filesystem_Base
	 */
	protected $filesystem = null;

	/**
	 * {@inheritDoc}
	 */
	public function register( $container ) {
		// Nothing to register.
	}

	/**
	 * {@inheritDoc}
	 */
	public function bootstrap( $container ) {
		$this->filesystem = $container[ WPEMERGE_APPLICATION_FILESYSTEM_KEY ];

		// add_action( 'wp_enqueue_scripts', [$this, 'enqueueFrontendAssets'] );
		add_action( 'admin_enqueue_scripts', [$this, 'enqueueAdminAssets'] );
		// add_action( 'wp_footer', [$this, 'loadSvgSprite'] );
	}

	/**
	 * Enqueue frontend assets.
	 *
	 * @return void
	 */
	public function enqueueFrontendAssets() {
		// Enqueue the built-in comment-reply script for singular pages.
		if ( is_singular() ) {
			wp_enqueue_script( 'comment-reply' );
		}

		// Enqueue scripts.
		\AaspCustomProducts::core()->assets()->enqueueScript(
			'theme-js-bundle',
			\AaspCustomProducts::core()->assets()->getBundleUrl( 'frontend', '.js' ),
			[ 'jquery' ],
			true
		);

		// Enqueue styles.
		$style = \AaspCustomProducts::core()->assets()->getBundleUrl( 'frontend', '.css' );

		if ( $style ) {
			\AaspCustomProducts::core()->assets()->enqueueStyle(
				'theme-css-bundle',
				$style
			);
		}
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @return void
	 */
	public function enqueueAdminAssets() {
		// Enqueue scripts.
		// \AaspCustomProducts::core()->assets()->enqueueScript(
		// 	'theme-admin-js-bundle',
		// 	\AaspCustomProducts::core()->assets()->getBundleUrl( 'admin', '.js' ),
		// 	[ 'jquery' ],
		// 	true
		// );

		// Enqueue styles.
		$style = \AaspCustomProducts::core()->assets()->getBundleUrl( 'style', '.css' );

		if ( $style ) {
			\AaspCustomProducts::core()->assets()->enqueueStyle(
				'theme-admin-css',
				$style
			);
		}
	}

	/**
	 * Load SVG sprite.
	 *
	 * @return void
	 */
	public function loadSvgSprite() {
		$file_path = implode(
			DIRECTORY_SEPARATOR,
			array_filter(
				[
					get_template_directory(),
					'dist',
					'images',
					'sprite.svg',
				]
			)
		);

		if ( ! $this->filesystem->exists( $file_path ) ) {
			return;
		}

		echo $this->filesystem->get_contents( $file_path );
	}
}
