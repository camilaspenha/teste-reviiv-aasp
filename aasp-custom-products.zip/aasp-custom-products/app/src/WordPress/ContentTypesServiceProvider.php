<?php

namespace AaspCustomProducts\WordPress;

use WPEmerge\ServiceProviders\ServiceProviderInterface;

/**
 * Register widgets and sidebars.
 */
class ContentTypesServiceProvider implements ServiceProviderInterface {
	/**
	 * {@inheritDoc}
	 */
	public function register( $container ) {
		// Nothing to register.
	}

	/**
	 * {@inheritDoc}
	 */
	public function bootstrap( $container ) {
		add_action( 'init', [$this, 'registerPostTypes'] );
		add_action( 'init', [$this, 'registerTaxonomies'] );
	}

	/**
	 * Register post types.
	 *
	 * @return void
	 */
	public function registerPostTypes() {
		// phpcs:disable
		/*
		register_post_type(
			'aasp_custom_products_custom_post_type',
			array(
				'labels'              => array(
					'name'               => __( 'Custom Types', 'aasp_custom_products' ),
					'singular_name'      => __( 'Custom Type', 'aasp_custom_products' ),
					'add_new'            => __( 'Add New', 'aasp_custom_products' ),
					'add_new_item'       => __( 'Add new Custom Type', 'aasp_custom_products' ),
					'view_item'          => __( 'View Custom Type', 'aasp_custom_products' ),
					'edit_item'          => __( 'Edit Custom Type', 'aasp_custom_products' ),
					'new_item'           => __( 'New Custom Type', 'aasp_custom_products' ),
					'search_items'       => __( 'Search Custom Types', 'aasp_custom_products' ),
					'not_found'          => __( 'No custom types found', 'aasp_custom_products' ),
					'not_found_in_trash' => __( 'No custom types found in trash', 'aasp_custom_products' ),
				),
				'public'              => true,
				'exclude_from_search' => false,
				'show_ui'             => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'query_var'           => true,
				'menu_icon'           => 'dashicons-admin-post',
				'supports'            => array( 'title', 'editor', 'page-attributes' ),
				'rewrite'             => array(
					'slug'       => 'custom-post-type',
					'with_front' => false,
				),
			)
		);
		*/
		// phpcs:enable
	}

	/**
	 * Register taxonomies.
	 *
	 * @return void
	 */
	public function registerTaxonomies() {
		// phpcs:disable
		/*
		register_taxonomy(
			'aasp_custom_products_custom_taxonomy',
			array( 'post_type' ),
			array(
				'labels'            => array(
					'name'              => __( 'Custom Taxonomies', 'aasp_custom_products' ),
					'singular_name'     => __( 'Custom Taxonomy', 'aasp_custom_products' ),
					'search_items'      => __( 'Search Custom Taxonomies', 'aasp_custom_products' ),
					'all_items'         => __( 'All Custom Taxonomies', 'aasp_custom_products' ),
					'parent_item'       => __( 'Parent Custom Taxonomy', 'aasp_custom_products' ),
					'parent_item_colon' => __( 'Parent Custom Taxonomy:', 'aasp_custom_products' ),
					'view_item'         => __( 'View Custom Taxonomy', 'aasp_custom_products' ),
					'edit_item'         => __( 'Edit Custom Taxonomy', 'aasp_custom_products' ),
					'update_item'       => __( 'Update Custom Taxonomy', 'aasp_custom_products' ),
					'add_new_item'      => __( 'Add New Custom Taxonomy', 'aasp_custom_products' ),
					'new_item_name'     => __( 'New Custom Taxonomy Name', 'aasp_custom_products' ),
					'menu_name'         => __( 'Custom Taxonomies', 'aasp_custom_products' ),
				),
				'hierarchical'      => true,
				'show_ui'           => true,
				'show_admin_column' => true,
				'query_var'         => true,
				'rewrite'           => array( 'slug' => 'custom-taxonomy' ),
			)
		);
		*/
		// phpcs:enable
	}
}
