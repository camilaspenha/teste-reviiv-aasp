<?php

namespace AaspCustomProducts\Wordpress\Services;

use WP_Query;

class ProdutoService {

    public function getProdutos() {
		$html = '';
		$per_page = 2;
		$current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;

        $args = [
			'post_type' => 'product',
			'posts_per_page' => $per_page,
			'paged' => $current_page,
		];

		$query = new WP_Query($args);
		if ($query->have_posts()) {

			$html .= '<table class="wp-list-table widefat fixed striped">';
			$html .= '<thead><tr>';
			$html .= '<th>Produto</th>';
			$html .= '<th>Descrição Técnica</th>';
			$html .= '<th>Nível de Complexidade</th>';
			$html .= '<th>Horas de Estudo</th>';
			$html .= '<th>Pedidos</th>';
			$html .= '</tr></thead>';
			$html .= '<tbody>';

			while ($query->have_posts()) {
				$query->the_post();
				$product = wc_get_product( get_the_ID() );
				$title = get_the_title();
				$descricao_tecnica = carbon_get_post_meta( get_the_ID(), 'descricao_tecnica' );
				$nivel_complexidade = carbon_get_post_meta( get_the_ID(), 'nivel_complexidade' );
				$horas_estudo = carbon_get_post_meta( get_the_ID(), 'horas_estudo' );

				global $wpdb;
				$order_count = $wpdb->get_var($wpdb->prepare("
					SELECT COUNT(DISTINCT order_items.order_id)
					FROM {$wpdb->prefix}woocommerce_order_items AS order_items
					LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta AS itemmeta
					ON order_items.order_item_id = itemmeta.order_item_id
					WHERE itemmeta.meta_key = '_product_id'
					AND itemmeta.meta_value = %d
				", $product));

				$html .= '<tr>';
				$html .= '<td>' . esc_html($title) . '</td>';
				$html .= '<td>' . esc_html($descricao_tecnica) . '</td>';
				$html .= '<td>' . esc_html($nivel_complexidade) . '</td>';
				$html .= '<td>' . esc_html($horas_estudo) . '</td>';
				$html .= '<td>' . esc_html($order_count) . '</td>';
				$html .= '</tr>';

			}

			$html .= '</tbody>';
			$html .= '</table>';

			// pagination
			$total_products = $query->found_posts;
			$total_pages = ceil($total_products / $per_page);

			$page_links = paginate_links([
				'total' => $total_pages,
				'current' => $current_page,
				'format' => '?paged=%#%',
				'prev_text' => __('« Anterior'),
				'next_text' => __('Próximo »'),
			]);

			$html.= '<div class="tablenav"><div class="tablenav-pages">';
			$html .= $page_links;
			$html .= '</div></div>';

			} else {
				$html = "<p>Nenhum produto encontrado.</p>";
			}
			wp_reset_postdata();
			return $html;
		}
}
