<?php
/**
 * An example view.
 *
 * Layout: layouts/example.php
 *
 * @package AaspCustomProducts
 */

?>
<div class="aasp_custom_products__view">
	<?php \AaspCustomProducts::render( 'partials/example', [ 'message' => __( 'Hello World!', 'aasp_custom_products' ) ] ); ?>
</div>
