<?php
/**
 * An example layout.
 *
 * @link https://docs.wpemerge.com/#/framework/views/layouts
 *
 * @package AaspCustomProducts
 */

?>
<div class="aasp_custom_products__layout">
	<?php \AaspCustomProducts::layoutContent(); ?>
</div>
