<?php
/**
 * An example partial view.
 *
 * @package AaspCustomProducts
 */

?>
<div class="aasp_custom_products__partial">
	<?php echo esc_html( $message ); ?>
</div>
