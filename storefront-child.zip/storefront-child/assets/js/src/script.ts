const validaButton = document.querySelector<HTMLButtonElement>('#valida-produto')!
const spinner = document.querySelector<HTMLDivElement>('#spinner')!
const respostaApi = document.querySelector<HTMLDivElement>('#resposta-api')!

let btnLabelText = validaButton.querySelector<HTMLSpanElement>('.btn-label')!.textContent
let btnLabel = validaButton.querySelector<HTMLSpanElement>('.btn-label')!
let newLabel = "Validando..."

validaButton.onclick = () => {
  
  spinner.style.display = 'block'
  validaButton.disabled = true
  btnLabel.textContent = newLabel
  respostaApi.textContent = ""
  respostaApi.classList = "mt-3"

  setTimeout(() => {
    fetch('https://mock-api.aasp.com.br/workflow/validate-product', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        productId: validaButton.dataset.id,
      })
  })
  .then(response => response.json())
  .then(data => {
      if (data.valid) {
        respostaApi.textContent = 'Produto validado com sucesso!'
        respostaApi.classList = "mt-3 alert alert-success"
      } else {
        respostaApi.textContent = 'Produto inválido!'
        respostaApi.classList = "mt-3 alert alert-danger"
      }
    }
  )
  .catch(error => {
      console.error('Erro ao validar produto. ' + error);
      respostaApi.textContent = 'Erro ao validar o produto.'
      respostaApi.classList = "mt-3 alert alert-danger"
      
    }
  )
  .finally(() => {
    spinner.style.display = 'none'
    validaButton.disabled = false
    btnLabel.textContent = btnLabelText
  })
   }, 3000);
}
