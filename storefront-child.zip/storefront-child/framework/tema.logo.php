<?php 

function permitir_svg_apenas_admin($mimes) {
    if (current_user_can('administrator')) {
        $mimes['svg'] = 'image/svg+xml';
    }
    return $mimes;
}
add_filter('upload_mimes', 'permitir_svg_apenas_admin');