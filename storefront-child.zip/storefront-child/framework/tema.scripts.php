<?php 

add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('aasp-style', get_stylesheet_uri());
    wp_enqueue_script('aasp-script', get_stylesheet_directory_uri() . '/assets/js/dist/assets/index.js', array(), null, true);
}, 30);