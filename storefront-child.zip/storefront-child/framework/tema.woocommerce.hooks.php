<?php 
add_filter('woocommerce_product_tabs', function($tabs) {

    $descricao_tecnica = carbon_get_the_post_meta('descricao_tecnica');
    $nivel_complexidade = carbon_get_the_post_meta('nivel_complexidade');
    $horas_estudo = carbon_get_the_post_meta('horas_estudo');

    if (!$descricao_tecnica && !$nivel_complexidade && !$horas_estudo) {
        return $tabs; // No fields filled, do not add the tab
    } else {
        $tabs['info_juridica'] = array(
            'title'    => 'Informações Jurídicas',
            'priority' => 50,
            'callback' => 'exibir_info_juridica_tab'
        );
    }
    return $tabs;
});

function exibir_info_juridica_tab() {
    $descricao_tecnica = carbon_get_the_post_meta('descricao_tecnica');
    $nivel_complexidade = carbon_get_the_post_meta('nivel_complexidade');
    $horas_estudo = carbon_get_the_post_meta('horas_estudo');

    echo '<div class="campos-juridicos">';
    echo '<h3>Informações Jurídicas do Produto</h3>';
    if ($descricao_tecnica) {
        echo '<p><strong>Descrição Técnica:</strong></br> ' . esc_html($descricao_tecnica) . '</p>';
    }
    if ($nivel_complexidade) {
        echo '<p><strong>Nível de Complexidade:</strong></br>' . esc_html($nivel_complexidade) . '</p>';
    }
    if ($horas_estudo) {
        echo '<p><strong>Horas de estudo:</strong></br> ' . esc_html($horas_estudo) . '</p>';
    }
    echo '</div>';
}