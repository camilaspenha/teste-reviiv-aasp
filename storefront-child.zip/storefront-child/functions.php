<?php 
require_once get_stylesheet_directory() . '/framework/tema.scripts.php';
require_once get_stylesheet_directory() . '/framework/tema.carbon.fields.php';
require_once get_stylesheet_directory() . '/framework/tema.logo.php';
require_once get_stylesheet_directory() . '/framework/tema.woocommerce.hooks.php';