<?php

use Carbon_Fields\Container;
use Carbon_Fields\Field;

add_action('carbon_fields_register_fields', function () {
  Container::make('post_meta', 'Informações Jurídicas')
    ->where('post_type', '=', 'product')
    ->add_fields([
      Field::make('textarea', 'descricao_tecnica', 'Descrição Técnica'),
      Field::make('text', 'nivel_complexidade', 'Nível de Complexidade'),
      Field::make('text', 'horas_estudo', 'Quantidade Estimada de Horas de Estudo'),
    ]);
});

add_action('after_setup_theme', function () {
  \Carbon_Fields\Carbon_Fields::boot();
});