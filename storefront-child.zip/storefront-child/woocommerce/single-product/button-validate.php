<?php
/**
 * Single Product Button Validate
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/validate.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see        https://woocommerce.com/document/template-structure/
 * @package    WooCommerce\Templates
 * @version    1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

<div style="display:block; margin: 10px 0;clear:both;">
  <button id="valida-produto" data-id="<?php the_ID(); ?>"  class="button alt d-flex align-items-center justify-content-center gap-3">
    <div id="spinner" class="spinner-border" role="status" style="display:none;">
      <span class="sr-only"></span>
    </div>
    <span class="btn-label">Validar conteúdo jurídico com sistema externo</span></button>
  <div id="resposta-api"></div>
</div>


